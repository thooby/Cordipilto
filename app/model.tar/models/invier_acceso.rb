class InvierAcceso < ActiveRecord::Base
  has_many :fincas
end
