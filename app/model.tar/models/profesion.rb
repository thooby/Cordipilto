class Profesion < ActiveRecord::Base
  has_many :personas
end
