class TipoSuelo < ActiveRecord::Base
  has_many :fincas
end
