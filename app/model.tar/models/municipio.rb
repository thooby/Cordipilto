class Municipio < ActiveRecord::Base
  has_many :fincas
end
