class Naciona < ActiveRecord::Base
  has_many :personas
end
