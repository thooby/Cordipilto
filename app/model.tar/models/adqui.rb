class Adqui < ActiveRecord::Base
  has_many :fincas
end
