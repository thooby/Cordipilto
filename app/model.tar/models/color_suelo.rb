class ColorSuelo < ActiveRecord::Base
  has_many :fincas
end
