class Topogra < ActiveRecord::Base
  has_many :fincas
end
