class Finca < ActiveRecord::Base
  has_many :personas
  belongs_to :agua
  belongs_to :municipio
  belongs_to :acceso
  belongs_to :invier_acceso
  belongs_to :verano_acceso
  belongs_to :tipo_suelo
  belongs_to :color_suelo
  belongs_to :profun_suelo
  belongs_to :topogra
  belongs_to :fertiliza
  belongs_to :comunidad
  belongs_to :adqui
end