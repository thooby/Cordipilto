class VeranoAcceso < ActiveRecord::Base
  has_many :fincas
end
