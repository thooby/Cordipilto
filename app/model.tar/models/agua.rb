class Agua < ActiveRecord::Base
  has_many :fincas
end
