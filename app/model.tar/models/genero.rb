class Genero < ActiveRecord::Base
  has_many :personas
end
