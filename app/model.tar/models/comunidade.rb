class Comunidade < ActiveRecord::Base
  has_many :fincas
end
