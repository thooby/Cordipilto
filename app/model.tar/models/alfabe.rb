class Alfabe < ActiveRecord::Base
  has_many :personas
end
