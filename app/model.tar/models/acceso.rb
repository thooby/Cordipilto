class Acceso < ActiveRecord::Base
  has_many :fincas
end
